package com.example.bletutorial.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

// Définit le screen
@Composable
fun StartScreen(
    // Contrôleur de naviagtion entre Screen
    navController: NavController
) {
    // Définition d'une Box qui contient notre bouton
    Box(
        // Occupe tout l'écran
        modifier = Modifier.fillMaxSize(),
        // Centre tout
        contentAlignment = Alignment.Center
    ){
        // Bouton pour lancer le Scan et la connexion BLES
        Box(
            // Définition de l'apparence du bouton
            modifier = Modifier
                .size(180.dp)
                .clip(CircleShape)
                .background(Color.Blue, CircleShape)
                // Définit l'action au clic, ici on va à l'écran Temperature et humidity
                .clickable {
                    navController.navigate(Screen.Data_V2.route){
                        popUpTo(Screen.StartScreen.route){
                            inclusive = true
                        }
                    }
                },
            contentAlignment = Alignment.Center
        ){
            // Ajoute le text au bouton
            Text(
                text = "Scan",
                fontSize = 35.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }

}






