package com.example.bletutorial.presentation



import android.bluetooth.BluetoothAdapter
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.modifier.modifierLocalConsumer
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation.NavController
import androidx.navigation.Navigation.findNavController
import androidx.navigation.compose.rememberNavController
import com.example.bletutorial.data.ConnectionState
import com.example.bletutorial.data.permissions.PermissionUtils
import com.example.bletutorial.data.permissions.SystemBroadcastReceiver
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState


@OptIn(ExperimentalPermissionsApi::class, ExperimentalMaterialApi::class)

@Composable
fun DataV2(
    navController: NavController
    //Définit rapidement la fonction (sans argument ni return)
    //onBluetoothStateChanged:()->Unit,
    //navController: NavController,
    //viewModel: TempHumidityViewModel = hiltViewModel()

) {

    // Var
    val options_state = listOf("Off", "Active", "Flapping")
    var expanded by remember { mutableStateOf(false) }
    var selectedOptionText by remember { mutableStateOf(options_state[0]) }

    // Conteneur qui occupe tout l'écran
    Box(
        modifier = Modifier
            .fillMaxSize(),
        contentAlignment = Alignment.Center
    ){
        // Organise le contenu de manière vertical
        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .fillMaxHeight(0.9f)
                /*.border(
                    BorderStroke(
                        2.dp, Color.Black
                    ),
                    RoundedCornerShape(8.dp)
                ) */,
            verticalArrangement = Arrangement.SpaceAround,
            horizontalAlignment = Alignment.CenterHorizontally
        ){

            /* Accéléro */
           OutlinedTextField(
               value = "10",
               onValueChange = {  },
               textStyle =  TextStyle(color = Color.Black, fontSize = 30.sp,  textAlign = TextAlign.Center),
               colors = TextFieldDefaults.outlinedTextFieldColors(
                    focusedBorderColor =  MaterialTheme.colors.primaryVariant,
                    unfocusedBorderColor = MaterialTheme.colors.primaryVariant,
                    focusedLabelColor = MaterialTheme.colors.primaryVariant,
                    unfocusedLabelColor = MaterialTheme.colors.primaryVariant),
               readOnly = true,
               maxLines = 1,
               label = { Text("XL" , fontSize = 20.sp) },
               modifier = Modifier
                   .height(80.dp),

           )

            /* MLC */
            OutlinedTextField(
                value = "10",
                onValueChange = {  },
                textStyle =  TextStyle(color = Color.Black, fontSize = 30.sp,  textAlign = TextAlign.Center),
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    focusedBorderColor =  MaterialTheme.colors.primaryVariant,
                    unfocusedBorderColor = MaterialTheme.colors.primaryVariant,
                    focusedLabelColor = MaterialTheme.colors.primaryVariant,
                    unfocusedLabelColor = MaterialTheme.colors.primaryVariant),
                readOnly = true,
                maxLines = 1,
                label = { Text("MLC" , fontSize = 20.sp) },
                modifier = Modifier
                    .height(80.dp),
                )

            /* Threshold */
            OutlinedTextField(
                value = "10",
                onValueChange = {  },
                textStyle =  TextStyle(color = Color.Black, fontSize = 30.sp,  textAlign = TextAlign.Center),
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    focusedBorderColor =  MaterialTheme.colors.primaryVariant,
                    unfocusedBorderColor = MaterialTheme.colors.primaryVariant,
                    focusedLabelColor = MaterialTheme.colors.primaryVariant,
                    unfocusedLabelColor = MaterialTheme.colors.primaryVariant),
                readOnly = true,
                maxLines = 1,
                label = { Text("Threshold" , fontSize = 20.sp) },
                modifier = Modifier
                    .height(80.dp),
                )

            /* Real state*/
            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = {
                    expanded = !expanded
                }
            ) {
                TextField(
                    readOnly = true,
                    textStyle =  TextStyle(color = Color.Black, fontSize = 20.sp,  textAlign = TextAlign.Center),
                    value = selectedOptionText,
                    onValueChange = { },
                    label = { Text("Sail state", fontSize = 20.sp) },
                    //label = { Text("Threshold" , fontSize = 20.sp) },
                    trailingIcon = {
                        ExposedDropdownMenuDefaults.TrailingIcon(
                            expanded = expanded
                        )
                    },
                    colors = ExposedDropdownMenuDefaults.textFieldColors()
                )
                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = {
                        expanded = false
                    }
                ) {
                    options_state.forEach { selectionOption ->
                        DropdownMenuItem(
                            onClick = {
                                selectedOptionText = selectionOption
                                expanded = false
                            }
                        ) {
                            Text(text = selectionOption)
                        }
                    }
                }
            }

            // Retour au SCAN
            IconButton(onClick = {
                navController.navigate(Screen.StartScreen.route){}
            })
            {
                Icon(
                    imageVector = Icons.Filled.ArrowBack,
                    contentDescription = "Back"
                )
                /*Row() {
                    //Icon(bitmap ="arrow_back" , contentDescription = "back")
                    Text(
                        "👈 Back to SCAN"
                    )
                }*/


            }

        }
    }
}













