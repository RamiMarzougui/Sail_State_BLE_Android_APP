package com.example.bletutorial.data

// Structure pour les datas des capteurs
data class TempHumidityResult(
    val temperature:Float,
    val humidity:Float,
    val connectionState: ConnectionState
)
