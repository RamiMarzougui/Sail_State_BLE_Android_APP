package com.example.bletutorial

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class BLEApplikation : Application() {
}