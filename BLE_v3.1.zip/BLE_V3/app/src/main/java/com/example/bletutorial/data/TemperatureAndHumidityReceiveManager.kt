package com.example.bletutorial.data

import com.example.bletutorial.util.Resource
import kotlinx.coroutines.flow.MutableSharedFlow

interface TemperatureAndHumidityReceiveManager {

    val data: MutableSharedFlow<Resource<TempHumidityResult>>

    /*
    Toutes ces fonctions sont oveeride dans
    TemperatureAndHumidityBLEReceiveManager
     */

    fun reconnect()

    fun disconnect()

    fun startReceiving()

    fun closeConnection()

}